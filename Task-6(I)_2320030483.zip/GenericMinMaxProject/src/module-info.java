/**
 * 
 */
/**
 * 
 */
module GenericMinMaxProject {
}